//
// Created by alpacox on 05/03/21.
//

#ifndef DRAGHI_E_SOTTERRANEI_SKELETON_H
#define DRAGHI_E_SOTTERRANEI_SKELETON_H


#include "Enemy.h"

class Skeleton : public Enemy{

};


#endif //DRAGHI_E_SOTTERRANEI_SKELETON_H
