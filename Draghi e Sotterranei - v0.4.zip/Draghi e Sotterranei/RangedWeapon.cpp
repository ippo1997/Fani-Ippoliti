//
// Created by alpacox on 12/03/21.
//

#include "RangedWeapon.h"

RangedWeapon::RangedWeapon(int s, int ar, bool m, bool h) : Weapon(s, m, h), ammos(ar){

}

int RangedWeapon::use() {
    int result = 0;
    if (ammos) {
        result = basicUse();
        ammos--;
    }
    return result;
}

RangedWeapon* RangedWeapon::clone() const {
    return new RangedWeapon(*this);
}