//
// Created by alpacox on 12/03/21.
//

#ifndef DRAGHI_E_SOTTERRANEI_RANGEDWEAPON_H
#define DRAGHI_E_SOTTERRANEI_RANGEDWEAPON_H

#include "Weapon.h"


class RangedWeapon: public Weapon {
public:
    explicit RangedWeapon(int s = 10, int ar = 10, bool m = false, bool h = false);


    virtual int use() override;
    virtual RangedWeapon* clone() const override;

    int getAmmos() const {
        return ammos;
    }

    void setAmmos(int ar) {
        RangedWeapon::ammos = ar;
    }

protected:
    int ammos;


};


#endif //DRAGHI_E_SOTTERRANEI_RANGEDWEAPON_H
