//
// Created by alpacox on 12/03/21.
//

#ifndef DRAGHI_E_SOTTERRANEI_MARTIALWEAPON_H
#define DRAGHI_E_SOTTERRANEI_MARTIALWEAPON_H

#include "Weapon.h"

class MartialWeapon: public Weapon {
public:
    explicit MartialWeapon(int s = 10, bool m = false, bool h = false);

    virtual int use() override;
    virtual MartialWeapon* clone() const override;





};


#endif //DRAGHI_E_SOTTERRANEI_MARTIALWEAPON_H
