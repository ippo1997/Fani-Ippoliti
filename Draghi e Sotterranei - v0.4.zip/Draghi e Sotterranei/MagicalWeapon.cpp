//
// Created by alpacox on 15/03/21.
//

#include "MagicalWeapon.h"

MagicalWeapon::MagicalWeapon(int s, int mf, bool m, bool h) : MartialWeapon(s, m, h), RangedWeapon(s, m, mf){

}

int MagicalWeapon::use() {
    int result = 0;
    if (ammos) {
        result = RangedWeapon::use();
    } else
        result = MartialWeapon::use();
} // TODO da sviluppare i metodi di combattimento per le armi a distanza e corpo a corpo in modo da determinare il metodo di combattimento delle armi magiche a second che abbiano ancora "carburante magico" oppure no

