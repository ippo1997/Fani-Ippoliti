//
// Created by alpacox on 05/03/21.
//

#ifndef DRAGHI_E_SOTTERRANEI_ARCHER_H
#define DRAGHI_E_SOTTERRANEI_ARCHER_H


#include "Hero.h"

class Archer : public Hero{

};


#endif //DRAGHI_E_SOTTERRANEI_ARCHER_H
