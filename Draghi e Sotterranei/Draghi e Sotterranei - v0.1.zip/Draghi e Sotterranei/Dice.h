//
// Created by alpacox on 05/03/21.
//

#ifndef DRAGHI_E_SOTTERRANEI_DICE_H
#define DRAGHI_E_SOTTERRANEI_DICE_H


class Dice {

};


#endif //DRAGHI_E_SOTTERRANEI_DICE_H
