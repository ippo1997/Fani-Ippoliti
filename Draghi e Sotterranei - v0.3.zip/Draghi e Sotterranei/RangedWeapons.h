//
// Created by alpacox on 12/03/21.
//

#ifndef DRAGHI_E_SOTTERRANEI_RANGEDWEAPONS_H
#define DRAGHI_E_SOTTERRANEI_RANGEDWEAPONS_H

#include "Weapon.h"


class RangedWeapons: public Weapon {


    virtual int use() override;
    virtual RangedWeapons* clone() const override;

    int getArrows() const {
        return arrows;
    }

    void setArrows(int arrows) {
        RangedWeapons::arrows = arrows;
    }

protected:
    int arrows;


};


#endif //DRAGHI_E_SOTTERRANEI_RANGEDWEAPONS_H
