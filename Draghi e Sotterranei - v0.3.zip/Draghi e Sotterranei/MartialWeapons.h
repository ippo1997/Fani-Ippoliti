//
// Created by alpacox on 12/03/21.
//

#ifndef DRAGHI_E_SOTTERRANEI_MARTIALWEAPONS_H
#define DRAGHI_E_SOTTERRANEI_MARTIALWEAPONS_H

#include "Weapon.h"

class MartialWeapons: public Weapon {

    virtual int use() override;
    virtual MartialWeapons* clone() const override;




};


#endif //DRAGHI_E_SOTTERRANEI_MARTIALWEAPONS_H
