//
// Created by alpacox on 05/03/21.
//

#ifndef DRAGHI_E_SOTTERRANEI_MAGE_H
#define DRAGHI_E_SOTTERRANEI_MAGE_H


#include "Hero.h"

class Mage : public Hero{

};


#endif //DRAGHI_E_SOTTERRANEI_MAGE_H
