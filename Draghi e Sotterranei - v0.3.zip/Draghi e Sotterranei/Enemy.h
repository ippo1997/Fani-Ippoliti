//
// Created by alpacox on 05/03/21.
//

#ifndef DRAGHI_E_SOTTERRANEI_ENEMY_H
#define DRAGHI_E_SOTTERRANEI_ENEMY_H


#include "GameCharacter.h"

class Enemy : public GameCharacter {
public:



protected:

};


#endif //DRAGHI_E_SOTTERRANEI_ENEMY_H
