#include <iostream>
#include "Dice.h"

int main() {
    /*int value=0;
    Dice d20(20);
    for(int i= 0; i<50; i++) {           <-PROVA DADO
        value = d20.roll(1);
        std::cout<< value << std::endl;
    } */
    return 0;
}
