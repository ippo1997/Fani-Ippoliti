//
// Created by alpacox on 15/03/21.
//

#ifndef DRAGHI_E_SOTTERRANEI_MAGICALWEAPONS_H
#define DRAGHI_E_SOTTERRANEI_MAGICALWEAPONS_H

#include "MartialWeapons.h"
#include "RangedWeapons.h"


class MagicalWeapons: public MartialWeapons, public RangedWeapons { // fino a che l'arma ha il "carburante magico" si comporta come ranged e quand lo finisce si comporta come martial


    virtual int use() override;
    virtual MagicalWeapons* clone() const override;

    int getMagicalFuel() const {
        return magicalFuel;
    }

    void setArrows(int mf) {
        MagicalWeapons::magicalFuel = mf;
    }

protected:
    int magicalFuel;

};


#endif //DRAGHI_E_SOTTERRANEI_MAGICALWEAPONS_H
