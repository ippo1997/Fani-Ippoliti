//
// Created by alpacox on 05/03/21.
//

#ifndef DRAGHI_E_SOTTERRANEI_EVILMAGE_H
#define DRAGHI_E_SOTTERRANEI_EVILMAGE_H


#include "Enemy.h"

class EvilMage : public Enemy{

};


#endif //DRAGHI_E_SOTTERRANEI_EVILMAGE_H
