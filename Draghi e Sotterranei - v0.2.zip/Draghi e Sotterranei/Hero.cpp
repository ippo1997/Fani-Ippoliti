//
// Created by alpacox on 05/03/21.
//

#include "Hero.h"
