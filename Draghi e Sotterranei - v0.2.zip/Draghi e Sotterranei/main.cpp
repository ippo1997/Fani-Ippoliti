#include <iostream>
#include "Dice.h"

int main() {
    int value=0;
    Dice d6(6);
    value = d6.roll(2);
    return 0;
}
